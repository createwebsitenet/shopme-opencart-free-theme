<?php
class ModelDesignthemesetting extends Model {
	

	public function editthemesetting($setting_id, $data) {
		$this->db->query("UPDATE " . DB_PREFIX . "themesetting SET name = '" . $this->db->escape($data['name']) . "',facebook = '" . $this->db->escape($data['facebook']) . "',twitter = '" . $this->db->escape($data['twitter']) . "',googleplus = '" . $this->db->escape($data['googleplus']) . "',pintrace = '" . $this->db->escape($data['pintrace']) . "',linkedin = '" . $this->db->escape($data['linkedin']) . "', status = '" . (int)$data['status'] . "' WHERE setting_id = '" . (int)$setting_id . "'");

}



	public function getsetting($setting_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "themesetting WHERE setting_id = '" . (int)$setting_id . "'");

		return $query->row;
	}


}
