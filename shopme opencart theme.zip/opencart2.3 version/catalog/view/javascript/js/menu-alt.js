/*
	Programmer: Lukasz Czerwinski
	CodeCanyon: http://codecanyon.net/user/Lukasz_Czerwinski
	
	If this script you like, please put a comment on codecanyon.
	
*/
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(7($){$.H.K=7(b){w c,j,n;b=z.F({i:E,y:1,A:1,q:1,s:0},b);c=$(8);j=c.6("9").3("4").6("a");n=r.u;j.f("e");7 v(){w a=$(8);d(b.A){d(a.3().3().3().D("4")){a.3().3().o(".h").3("4").6("9").p(b.i/1.2,7(){$(8).3("4").6("a").g().f("e")})}x{c.3().3().o(".h").3("4").6("9").p(b.i/1.2,7(){$(8).3("4").6("a").g().f("e")})}}d(a.l("t")=="e"){a.3("4").6("9").m(b.i,7(){a.g().f("h");d(b.q&&a.l("k").G>5){r.u.k=a.l("k")}})}d(a.l("t")=="h"){a.g().f("e");a.3("4").6("9").p(b.i)}C I}j.J(\'B\').B(v);d(b.y){c.6("a").L(7(){d(8.k==n){d(b.q){$(8).3("4").6("9").m(M,7(){$(8).3("4").6(".e").g().f("h")})}x{$(8).3("4").N("4").6("9").m(b.i,7(){$(8).3("4").6(".e").g().f("h")})}}})}d(b.s){j.3("4").6("9").o(".e").3("4").6("9").m(b.i,7(){$(8).3("4").6(".e").g().f("h")})}}})(z);',50,50,'|||parent|li||children|function|this|ul||||if|inactive|addClass|removeClass|active|Speed|item|href|attr|slideDown|httpAdress|find|slideUp|itemLink|window|openAll|class|location|_item|var|else|autostart|jQuery|autohide|click|return|is|220|extend|length|fn|false|unbind|menu|each|100|parents'.split('|'),0,{}));

$(document).ready(function (){  
  //Usage
  $(".menu ul li").menu({
  		itemLink: 1
  });
}); 