<?php
class ModelDesignthemesetting extends Model {
	public function getthemesetting($setting_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "themesetting  WHERE setting_id = '" . (int)$setting_id . "' ");
		return $query->rows;
	}
}
